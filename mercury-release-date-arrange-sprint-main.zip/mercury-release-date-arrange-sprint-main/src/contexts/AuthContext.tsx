import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';
import api from '../utils/api';

interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    // Initialize user state from localStorage and sessionStorage
    let storedUser = localStorage.getItem('mercury-user-v1');
    if (!storedUser) {
      storedUser = localStorage.getItem('user');
    }
    if (!storedUser) {
      storedUser = sessionStorage.getItem('mercury-user-v1');
    }
    if (!storedUser) {
      storedUser = sessionStorage.getItem('user');
    }
    
    if (storedUser) {
      try {
        return JSON.parse(storedUser);
      } catch (error) {
        console.error('Error parsing stored user data:', error);
        localStorage.removeItem('mercury-user-v1');
        localStorage.removeItem('user');
        sessionStorage.removeItem('mercury-user-v1');
        sessionStorage.removeItem('user');
        return null;
      }
    }
    return null;
  });
  
  const [isAuthenticated, setIsAuthenticated] = useState(!!user);

  useEffect(() => {
    // Update isAuthenticated when user changes
    setIsAuthenticated(!!user);
  }, [user]);

  const login = async (username: string, password: string): Promise<void> => {
    try {
      // Get admin credentials from API
      const adminCredentials = await api.getAdminCredentials();
      
      if (!adminCredentials) {
        throw new Error('Admin credentials not found. Please run the setup script first.');
      }

      // Check credentials
      if (username === adminCredentials.username && password === adminCredentials.password) {
        const userData: User = {
          id: '1',
          username: adminCredentials.username,
          email: 'admin@mercury.com', // Default email
          role: 'admin'
        };

        // Store user data
        const userDataString = JSON.stringify(userData);
        localStorage.setItem('mercury-user-v1', userDataString);
        localStorage.setItem('user', userDataString);
        sessionStorage.setItem('mercury-user-v1', userDataString);
        sessionStorage.setItem('user', userDataString);
        setUser(userData);
        setIsAuthenticated(true);
      } else {
        throw new Error('Invalid username or password');
      }
    } catch (error) {
      throw new Error('Failed to connect to server. Please make sure the backend is running.');
    }
  };

  const logout = () => {
    localStorage.removeItem('mercury-user-v1');
    localStorage.removeItem('user');
    sessionStorage.removeItem('mercury-user-v1');
    sessionStorage.removeItem('user');
    setUser(null);
    setIsAuthenticated(false);
  };

  const value: AuthContextType = {
    user,
    login,
    logout,
    isAuthenticated
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}; 