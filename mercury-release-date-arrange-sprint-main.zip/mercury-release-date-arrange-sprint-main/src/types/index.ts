export interface Transition {
  id: string;
  projectName: string;
  color: string; // Proje rengi
  startDate: string;
  endDate: string;
  taskLink: string;
  transitionTime: string;
  lastTestSubmissionDate: string;
  lastPackageBindingDate: string;
  regressionDeliveryDate: string;
  transitionDate: string;
  transitionManager: string;
  transitionAssistant: string;
  managerEmail?: string;
  managerPhone?: string;
  assistantEmail?: string;
  assistantPhone?: string;
}

export interface User {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'user';
}

export interface AuthContextType {
  user: User | null;
  login: (username: string, password: string) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

export interface LoginFormData {
  username: string;
  password: string;
}

export interface TransitionFormData {
  projectName: string;
  color: string;
  taskLink: string;
  transitionTime: string;
  lastTestSubmissionDate: string;
  lastPackageBindingDate: string;
  regressionDeliveryDate: string;
  transitionDate: string;
  transitionManager: string;
  transitionAssistant: string;
  managerEmail?: string;
  managerPhone?: string;
  assistantEmail?: string;
  assistantPhone?: string;
} 