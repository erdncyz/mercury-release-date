import React, { useState, useEffect, useRef } from 'react';
import { Phone, Mail } from 'lucide-react';

interface TooltipProps {
  children: React.ReactNode;
  content?: string; // Added for HomePage compatibility
  phone?: string;
  email?: string;
}

const Tooltip: React.FC<TooltipProps> = ({ children, content, phone, email }) => {
  const [isVisible, setIsVisible] = useState(false);
  const [tooltipPosition, setTooltipPosition] = useState({ top: 0, left: 0 });
  const tooltipRef = useRef<HTMLDivElement>(null);

  const hasContactInfo = phone || email;
  const hasContent = content;

  // Click outside to close
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (tooltipRef.current && !tooltipRef.current.contains(event.target as Node)) {
        setIsVisible(false);
      }
    };

    if (isVisible) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isVisible]);

  // Update tooltip position when it becomes visible
  useEffect(() => {
    if (isVisible && tooltipRef.current) {
      const rect = tooltipRef.current.getBoundingClientRect();
      setTooltipPosition({
        top: 20, // Fixed at top of page
        left: rect.left + (rect.width / 2) - 100 // Center horizontally
      });
    }
  }, [isVisible]);

  if (!hasContactInfo && !hasContent) {
    return <>{children}</>;
  }

  return (
    <div 
      ref={tooltipRef}
      className="relative inline-block"
      onClick={() => setIsVisible(!isVisible)}
    >
      {children}
      {isVisible && (
        <div 
          className="fixed z-[9999] px-4 py-3 text-sm text-white bg-indigo-600 rounded-lg shadow-xl whitespace-nowrap min-w-max border-2 border-white"
          style={{
            top: tooltipPosition.top,
            left: tooltipPosition.left,
            transform: 'translateX(-50%)'
          }}
        >
          {content ? (
            <div className="flex flex-col space-y-1">
              <span>{content}</span>
            </div>
          ) : (
            <div className="flex flex-col space-y-2">
              {phone && (
                <div className="flex items-center space-x-2">
                  <Phone className="h-4 w-4" />
                  <span className="font-medium">{phone}</span>
                </div>
              )}
              {email && (
                <div className="flex items-center space-x-2">
                  <Mail className="h-4 w-4" />
                  <span className="font-medium">{email}</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default Tooltip; 