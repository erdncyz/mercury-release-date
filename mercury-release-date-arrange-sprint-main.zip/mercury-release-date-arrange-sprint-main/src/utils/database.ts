import { Transition, TransitionFormData } from '../types';

// Database interface
interface Database {
  transitions: Transition[];
  adminCredentials: {
    username: string;
    password: string;
  };
  settings: {
    version: string;
    lastUpdated: string;
  };
}

// Default data structure
const DEFAULT_DATA: Database = {
  transitions: [],
  adminCredentials: {
    username: 'admin',
    password: 'admin123'
  },
  settings: {
    version: '1.0.0',
    lastUpdated: new Date().toISOString()
  }
};

// Sample transitions data - Empty array for clean start
const SAMPLE_TRANSITIONS: Transition[] = [];

// Database storage keys - Updated to force reset
const DB_KEY = 'mercury-database-v3';
const INIT_KEY = 'mercury-initialized-v3';

// Initialize database
const initializeDatabase = (): Database => {
  try {
    // Check if database exists
    const stored = localStorage.getItem(DB_KEY);
    if (stored) {
      const data = JSON.parse(stored);
      return data;
    }
    
    // Check if this is the first run
    const hasBeenInitialized = localStorage.getItem(INIT_KEY);
    if (!hasBeenInitialized) {
      // Create initial database with sample data
      const initialData: Database = {
        ...DEFAULT_DATA,
        transitions: SAMPLE_TRANSITIONS
      };
      
      saveDatabase(initialData);
      localStorage.setItem(INIT_KEY, 'true');
      return initialData;
    }
    
    // Return empty database
    return DEFAULT_DATA;
  } catch (error) {
    console.error('Database initialization error:', error);
    return DEFAULT_DATA;
  }
};

// Save database to localStorage
const saveDatabase = (data: Database): void => {
  try {
    const jsonData = JSON.stringify(data, null, 2);
    localStorage.setItem(DB_KEY, jsonData);
    
    // Also save to sessionStorage for backup
    sessionStorage.setItem(DB_KEY, jsonData);
  } catch (error) {
    console.error('Database save error:', error);
  }
};

// Get current database
const getDatabase = (): Database => {
  return initializeDatabase();
};

// Transition operations
export const getTransitions = (): Transition[] => {
  const db = getDatabase();
  return db.transitions;
};

export const addTransition = (transitionData: Partial<TransitionFormData>): Transition => {
  const db = getDatabase();
  const newTransition: Transition = {
    id: Date.now().toString(),
    projectName: transitionData.projectName || '',
    color: transitionData.color || '#3B82F6',
    startDate: '',
    endDate: '',
    taskLink: transitionData.taskLink || '',
    transitionTime: transitionData.transitionTime || '',
    lastTestSubmissionDate: transitionData.lastTestSubmissionDate || '',
    lastPackageBindingDate: transitionData.lastPackageBindingDate || '',
    regressionDeliveryDate: transitionData.regressionDeliveryDate || '',
    transitionDate: transitionData.transitionDate || '',
    transitionManager: transitionData.transitionManager || '',
    transitionAssistant: transitionData.transitionAssistant || '',
    managerEmail: transitionData.managerEmail || '',
    managerPhone: transitionData.managerPhone || '',
    assistantEmail: transitionData.assistantEmail || '',
    assistantPhone: transitionData.assistantPhone || '',
  };
  
  db.transitions.push(newTransition);
  db.settings.lastUpdated = new Date().toISOString();
  saveDatabase(db);
  return newTransition;
};

export const updateTransition = (id: string, transitionData: Partial<TransitionFormData>): Transition | null => {
  const db = getDatabase();
  const index = db.transitions.findIndex(t => t.id === id);
  
  if (index === -1) return null;
  
  const updatedTransition: Transition = {
    ...db.transitions[index],
    projectName: transitionData.projectName || db.transitions[index].projectName,
    color: transitionData.color || db.transitions[index].color,
    taskLink: transitionData.taskLink || db.transitions[index].taskLink,
    transitionTime: transitionData.transitionTime || db.transitions[index].transitionTime,
    lastTestSubmissionDate: transitionData.lastTestSubmissionDate || db.transitions[index].lastTestSubmissionDate,
    lastPackageBindingDate: transitionData.lastPackageBindingDate || db.transitions[index].lastPackageBindingDate,
    regressionDeliveryDate: transitionData.regressionDeliveryDate || db.transitions[index].regressionDeliveryDate,
    transitionDate: transitionData.transitionDate || db.transitions[index].transitionDate,
    transitionManager: transitionData.transitionManager || db.transitions[index].transitionManager,
    transitionAssistant: transitionData.transitionAssistant || db.transitions[index].transitionAssistant,
    managerEmail: transitionData.managerEmail || db.transitions[index].managerEmail || '',
    managerPhone: transitionData.managerPhone || db.transitions[index].managerPhone || '',
    assistantEmail: transitionData.assistantEmail || db.transitions[index].assistantEmail || '',
    assistantPhone: transitionData.assistantPhone || db.transitions[index].assistantPhone || '',
  };
  
  db.transitions[index] = updatedTransition;
  db.settings.lastUpdated = new Date().toISOString();
  saveDatabase(db);
  return updatedTransition;
};

export const deleteTransition = (id: string): boolean => {
  const db = getDatabase();
  const filteredTransitions = db.transitions.filter(t => t.id !== id);
  
  if (filteredTransitions.length === db.transitions.length) {
    return false; // Silinecek öğe bulunamadı
  }
  
  db.transitions = filteredTransitions;
  db.settings.lastUpdated = new Date().toISOString();
  saveDatabase(db);
  return true;
};

// Admin credentials operations
export const getAdminCredentials = () => {
  const db = getDatabase();
  return db.adminCredentials;
};

export const updateAdminCredentials = (username: string, password: string): void => {
  const db = getDatabase();
  db.adminCredentials = { username, password };
  db.settings.lastUpdated = new Date().toISOString();
  saveDatabase(db);
};

// Settings operations
export const getSettings = () => {
  const db = getDatabase();
  return db.settings;
};

// Database backup and restore
export const backupDatabase = (): string => {
  const db = getDatabase();
  return JSON.stringify(db, null, 2);
};

export const restoreDatabase = (backupData: string): boolean => {
  try {
    const data = JSON.parse(backupData);
    saveDatabase(data);
    return true;
  } catch (error) {
    console.error('Database restore error:', error);
    return false;
  }
};

// Export database utilities
const databaseUtils = {
  getTransitions,
  addTransition,
  updateTransition,
  deleteTransition,
  getAdminCredentials,
  updateAdminCredentials,
  getSettings,
  backupDatabase,
  restoreDatabase
};

export default databaseUtils; 