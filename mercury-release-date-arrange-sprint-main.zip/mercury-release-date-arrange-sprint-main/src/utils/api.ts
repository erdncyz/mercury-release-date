import { Transition, TransitionFormData } from '../types';

// API base URL - proxy kullanarak relative path
const API_BASE_URL = '/api';

// API utility functions
export const api = {
  // Transitions
  async getTransitions(): Promise<Transition[]> {
    const response = await fetch(`${API_BASE_URL}/transitions`);
    if (!response.ok) {
      throw new Error('Failed to fetch transitions');
    }
    return response.json();
  },

  async addTransition(transitionData: Partial<TransitionFormData>): Promise<Transition> {
    const response = await fetch(`${API_BASE_URL}/transitions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(transitionData),
    });
    if (!response.ok) {
      throw new Error('Failed to add transition');
    }
    return response.json();
  },

  async updateTransition(id: string, transitionData: Partial<TransitionFormData>): Promise<Transition> {
    const response = await fetch(`${API_BASE_URL}/transitions/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(transitionData),
    });
    if (!response.ok) {
      throw new Error('Failed to update transition');
    }
    return response.json();
  },

  async deleteTransition(id: string): Promise<boolean> {
    const response = await fetch(`${API_BASE_URL}/transitions/${id}`, {
      method: 'DELETE',
    });
    if (!response.ok) {
      throw new Error('Failed to delete transition');
    }
    return response.json().then(data => data.success);
  },

  // Admin credentials
  async getAdminCredentials() {
    const response = await fetch(`${API_BASE_URL}/admin/credentials`);
    if (!response.ok) {
      throw new Error('Failed to fetch admin credentials');
    }
    return response.json();
  },

  async updateAdminCredentials(username: string, password: string) {
    const response = await fetch(`${API_BASE_URL}/admin/credentials`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ username, password }),
    });
    if (!response.ok) {
      throw new Error('Failed to update admin credentials');
    }
    return response.json();
  },

  // Database info
  async getDatabaseInfo() {
    const response = await fetch(`${API_BASE_URL}/database/info`);
    if (!response.ok) {
      throw new Error('Failed to fetch database info');
    }
    return response.json();
  },

  async backupDatabase() {
    const response = await fetch(`${API_BASE_URL}/database/backup`);
    if (!response.ok) {
      throw new Error('Failed to backup database');
    }
    return response.json();
  },

  async restoreDatabase(backupData: any) {
    const response = await fetch(`${API_BASE_URL}/database/restore`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(backupData),
    });
    if (!response.ok) {
      throw new Error('Failed to restore database');
    }
    return response.json();
  },

  // Health check
  async healthCheck() {
    const response = await fetch(`${API_BASE_URL}/health`);
    if (!response.ok) {
      throw new Error('Server is not healthy');
    }
    return response.json();
  },
};

export default api; 