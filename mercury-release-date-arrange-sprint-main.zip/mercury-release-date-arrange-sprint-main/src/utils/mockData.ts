import { Transition, TransitionFormData } from '../types';
import api from './api';

// Önceden tanımlanmış renk seçenekleri
export const PROJECT_COLORS = [
  { name: 'Mavi', value: '#3B82F6', bg: 'bg-blue-500', text: 'text-blue-500' },
  { name: 'Yeşil', value: '#10B981', bg: 'bg-green-500', text: 'text-green-500' },
  { name: 'Mor', value: '#8B5CF6', bg: 'bg-purple-500', text: 'text-purple-500' },
  { name: 'Pembe', value: '#EC4899', bg: 'bg-pink-500', text: 'text-pink-500' },
  { name: 'Turuncu', value: '#F59E0B', bg: 'bg-orange-500', text: 'text-orange-500' },
  { name: 'Kırmızı', value: '#EF4444', bg: 'bg-red-500', text: 'text-red-500' },
  { name: 'İndigo', value: '#6366F1', bg: 'bg-indigo-500', text: 'text-indigo-500' },
  { name: 'Teal', value: '#14B8A6', bg: 'bg-teal-500', text: 'text-teal-500' },
  { name: 'Lime', value: '#84CC16', bg: 'bg-lime-500', text: 'text-lime-500' },
  { name: 'Amber', value: '#F59E0B', bg: 'bg-amber-500', text: 'text-amber-500' },
];

// Renk adından değer bulma fonksiyonu
export const getColorByName = (name: string) => {
  const color = PROJECT_COLORS.find(c => c.name === name);
  return color ? color.value : PROJECT_COLORS[0].value;
};

// Renk değerinden ad bulma fonksiyonu
export const getColorName = (value: string) => {
  const color = PROJECT_COLORS.find(c => c.value === value);
  return color ? color.name : PROJECT_COLORS[0].name;
};

// Renk değerinden Tailwind class'ları bulma fonksiyonu
export const getColorClasses = (value: string) => {
  const color = PROJECT_COLORS.find(c => c.value === value);
  return {
    bg: color ? color.bg : PROJECT_COLORS[0].bg,
    text: color ? color.text : PROJECT_COLORS[0].text
  };
};

// Database functions - now using the API system
export const getTransitions = async (): Promise<Transition[]> => {
  try {
    return await api.getTransitions();
  } catch (error) {
    console.error('Error fetching transitions:', error);
    return [];
  }
};

export const addTransition = async (transitionData: Partial<TransitionFormData>): Promise<Transition> => {
  return await api.addTransition(transitionData);
};

export const updateTransition = async (id: string, transitionData: Partial<TransitionFormData>): Promise<Transition | null> => {
  try {
    return await api.updateTransition(id, transitionData);
  } catch (error) {
    console.error('Error updating transition:', error);
    return null;
  }
};

export const deleteTransition = async (id: string): Promise<boolean> => {
  try {
    return await api.deleteTransition(id);
  } catch (error) {
    console.error('Error deleting transition:', error);
    return false;
  }
}; 