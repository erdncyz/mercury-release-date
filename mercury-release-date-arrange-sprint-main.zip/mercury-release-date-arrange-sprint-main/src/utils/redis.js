require('dotenv').config();
const Redis = require('ioredis');

// Redis bağlantı konfigürasyonu
const redisConfig = {
  host: process.env.REDIS_HOST || 'logservice-cache.luv0j6.0001.euw1.cache.amazonaws.com',
  port: parseInt(process.env.REDIS_PORT) || 6379,
  password: process.env.REDIS_PASSWORD || undefined,
  db: parseInt(process.env.REDIS_DB) || 0,
  retryDelayOnFailover: 100,
  enableReadyCheck: false,
  maxRetriesPerRequest: null,
  lazyConnect: true,
  keepAlive: 30000,
  connectTimeout: 10000,
  commandTimeout: 5000,
};

// Redis client instance
let redisClient = null;

// Redis bağlantısını başlat
const connectRedis = async () => {
  try {
    if (!redisClient) {
      redisClient = new Redis(redisConfig);
      
      redisClient.on('connect', () => {
        console.log('✅ Redis bağlantısı başarılı');
      });
      
      redisClient.on('error', (err) => {
        console.error('❌ Redis bağlantı hatası:', err);
      });
      
      redisClient.on('close', () => {
        console.log('🔌 Redis bağlantısı kapandı');
      });
    }
    
    return redisClient;
  } catch (error) {
    console.error('Redis bağlantı hatası:', error);
    throw error;
  }
};

// Redis'ten veri okuma
const getFromRedis = async (key) => {
  try {
    const client = await connectRedis();
    const data = await client.get(key);
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error(`Redis'ten veri okuma hatası (${key}):`, error);
    return null;
  }
};

// Redis'e veri yazma
const setToRedis = async (key, value, expireTime = parseInt(process.env.REDIS_TTL) || 86400) => {
  try {
    const client = await connectRedis();
    const serializedValue = JSON.stringify(value);
    await client.setex(key, expireTime, serializedValue);
    console.log(`✅ Redis'e yazıldı: ${key}`);
    return true;
  } catch (error) {
    console.error(`Redis'e veri yazma hatası (${key}):`, error);
    return false;
  }
};

// Redis'ten veri silme
const deleteFromRedis = async (key) => {
  try {
    const client = await connectRedis();
    await client.del(key);
    console.log(`🗑️ Redis'ten silindi: ${key}`);
    return true;
  } catch (error) {
    console.error(`Redis'ten veri silme hatası (${key}):`, error);
    return false;
  }
};

// Redis cache'i temizle
const clearRedisCache = async () => {
  try {
    const client = await connectRedis();
    const keys = await client.keys('mercury:*');
    if (keys.length > 0) {
      await client.del(...keys);
      console.log(`🗑️ ${keys.length} adet Mercury key'i silindi`);
    } else {
      console.log('ℹ️ Silinecek Mercury key bulunamadı');
    }
    return true;
  } catch (error) {
    console.error('Redis cache temizleme hatası:', error);
    return false;
  }
};

// Redis cache durumunu kontrol et
const getRedisCacheStatus = async () => {
  try {
    const client = await connectRedis();
    const keys = await client.keys('mercury:*');
    return {
      totalKeys: keys.length,
      keys: keys,
      databaseInfo: await getFromRedis(REDIS_KEYS.DATABASE_INFO)
    };
  } catch (error) {
    console.error('Redis cache durumu kontrol hatası:', error);
    return null;
  }
};

// Redis bağlantısını kapat
const disconnectRedis = async () => {
  try {
    if (redisClient) {
      await redisClient.quit();
      redisClient = null;
      console.log('🔌 Redis bağlantısı kapatıldı');
    }
  } catch (error) {
    console.error('Redis bağlantısını kapatma hatası:', error);
  }
};

// Redis key'leri
const REDIS_KEYS = {
  TRANSITIONS: 'mercury:transitions',
  ADMIN_CREDENTIALS: 'mercury:admin_credentials',
  SETTINGS: 'mercury:settings',
  DATABASE_INFO: 'mercury:database_info'
};

module.exports = {
  connectRedis,
  getFromRedis,
  setToRedis,
  deleteFromRedis,
  clearRedisCache,
  getRedisCacheStatus,
  disconnectRedis,
  REDIS_KEYS
}; 