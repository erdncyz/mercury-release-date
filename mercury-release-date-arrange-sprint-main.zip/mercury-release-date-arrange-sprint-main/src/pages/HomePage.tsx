import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Grid, List, Shield, Calendar, Clock, User, Users, ExternalLink, X } from 'lucide-react';
import { Transition } from '../types';
import { getTransitions } from '../utils/mockData';
import Tooltip from '../components/Tooltip';

const HomePage: React.FC = () => {
  const [transitions, setTransitions] = useState<Transition[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [viewMode, setViewMode] = useState<'table' | 'list'>(() => {
    // Get view mode from localStorage, default to 'table'
    const savedViewMode = localStorage.getItem('homeViewMode');
    return (savedViewMode as 'table' | 'list') || 'table';
  });
  const [showNoResults, setShowNoResults] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const loadTransitions = async () => {
      const transitions = await getTransitions();
      setTransitions(transitions);
    };
    loadTransitions();
  }, []);

  useEffect(() => {
    // Save view mode to localStorage whenever it changes
    localStorage.setItem('homeViewMode', viewMode);
  }, [viewMode]);

  const filteredTransitions = transitions.filter(transition => {
    // Search filter - check if search term matches project name only
    const searchLower = searchTerm.toLowerCase().trim();
    const matchesSearch = searchTerm === '' || 
      transition.projectName.toLowerCase().includes(searchLower);
    
    return matchesSearch;
  });

  useEffect(() => {
    if (searchTerm && filteredTransitions.length === 0) {
      setShowNoResults(true);
    } else {
      setShowNoResults(false);
    }
  }, [searchTerm, filteredTransitions.length]);

  // Transition time creation (for mock data)
  const getTransitionTime = (index: number) => {
    const times = [
      '05:00 - 07:00',
      '08:00 - 10:00', 
      '12:00 - 14:00',
      '15:00 - 17:00',
      '18:00 - 20:00'
    ];
    return times[index % times.length];
  };

  // Transition time color
  const getTimeColor = (index: number) => {
    const colors = ['bg-purple-500', 'bg-green-500', 'bg-pink-500', 'bg-purple-500', 'bg-pink-500'];
    return colors[index % colors.length];
  };

  const stats = {
    total: transitions.length
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-lg border-b border-white/20 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                Mercury Release Date
              </h1>
              <p className="text-gray-600 mt-1">Track project transitions</p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setViewMode('table')}
                  className={`p-2 rounded-lg transition-all duration-200 ${
                    viewMode === 'table' 
                      ? 'bg-indigo-100 text-indigo-600' 
                      : 'text-gray-400 hover:text-gray-600'
                  }`}
                >
                  <Grid className="h-5 w-5" />
                </button>
                <button
                  onClick={() => setViewMode('list')}
                  className={`p-2 rounded-lg transition-all duration-200 ${
                    viewMode === 'list' 
                      ? 'bg-indigo-100 text-indigo-600' 
                      : 'text-gray-400 hover:text-gray-600'
                  }`}
                >
                  <List className="h-5 w-5" />
                </button>
              </div>

              <div className="h-6 w-px bg-gray-300"></div>
              <button
                onClick={() => navigate('/login')}
                className="flex items-center px-4 py-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white rounded-xl hover:from-purple-700 hover:to-pink-700 focus:outline-none focus:ring-4 focus:ring-purple-500/30 transition-all duration-300 transform hover:scale-105 shadow-lg"
              >
                <Shield className="h-4 w-4 mr-2" />
                Admin Login
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-1 gap-6 mb-8">
          <div className="bg-white/80 backdrop-blur-lg rounded-2xl p-6 shadow-lg border border-white/20">
            <div className="flex items-center">
              <div className="p-3 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl">
                <Calendar className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Transitions</p>
                <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Search */}
        <div className="bg-white/80 backdrop-blur-lg rounded-2xl p-6 shadow-lg border border-white/20 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search by project name..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all duration-300"
                />
              </div>
            </div>
          </div>
          
          {/* Debug Info */}
          <div className="mt-4 pt-4 border-t border-gray-200">
            <div className="flex items-center justify-between text-sm text-gray-600">
              <div>
                <span className="font-medium">Search:</span> "{searchTerm}" | 
                <span className="font-medium ml-2">Results:</span> {filteredTransitions.length} of {transitions.length}
              </div>
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="text-indigo-600 hover:text-indigo-800 font-medium"
                >
                  Clear Search
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Content */}
        {viewMode === 'table' ? (
          <div className="bg-white/80 backdrop-blur-lg rounded-2xl shadow-lg border border-white/20">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900">Transition List</h2>
            </div>
            <div className="overflow-x-auto overflow-y-visible">
              <table className="w-full divide-y divide-gray-200 table-fixed">
                <thead className="bg-gradient-to-r from-purple-500 to-pink-500">
                  <tr>
                    <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-20">
                      <div className="flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        <span className="hidden sm:inline">TIME</span>
                        <span className="sm:hidden">T</span>
                      </div>
                    </th>
                    <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-24">
                      <div className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        <span className="hidden lg:inline">PROJECT</span>
                        <span className="lg:hidden">P</span>
                      </div>
                    </th>
                    <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-20">
                      <div className="flex items-center">
                        <ExternalLink className="h-3 w-3 mr-1" />
                        <span className="hidden md:inline">TASK</span>
                        <span className="md:hidden">T</span>
                      </div>
                    </th>
                    <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-20">
                      <div className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        <span className="hidden xl:inline">TEST</span>
                        <span className="xl:hidden">T</span>
                      </div>
                    </th>
                    <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-20">
                      <div className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        <span className="hidden xl:inline">PACKAGE</span>
                        <span className="xl:hidden">P</span>
                      </div>
                    </th>
                    <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-20">
                      <div className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        <span className="hidden xl:inline">REGRESSION</span>
                        <span className="xl:hidden">R</span>
                      </div>
                    </th>
                    <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-20">
                      <div className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        <span className="hidden lg:inline">DATE</span>
                        <span className="lg:hidden">D</span>
                      </div>
                    </th>
                    <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-24">
                      <div className="flex items-center">
                        <User className="h-3 w-3 mr-1" />
                        <span className="hidden md:inline">MANAGER</span>
                        <span className="md:hidden">M</span>
                      </div>
                    </th>
                    <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-24">
                      <div className="flex items-center">
                        <Users className="h-3 w-3 mr-1" />
                        <span className="hidden lg:inline">ASSISTANT</span>
                        <span className="lg:hidden">A</span>
                      </div>
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredTransitions.map((transition, index) => (
                    <tr key={transition.id} className="hover:bg-gray-50/50 transition-colors duration-200">
                      <td className="px-2 py-2 whitespace-nowrap">
                        <span className={`inline-flex items-center px-1 py-1 rounded-full text-xs font-medium text-white ${getTimeColor(index)}`}>
                          <span className="hidden sm:inline">{transition.transitionTime || getTransitionTime(index)}</span>
                          <span className="sm:hidden">{(transition.transitionTime || getTransitionTime(index)).split(' ')[0]}</span>
                        </span>
                      </td>
                      <td className="px-2 py-2 whitespace-nowrap">
                        <span className="inline-flex items-center px-1 py-1 rounded-full text-xs font-medium text-gray-900 bg-gray-200 truncate max-w-full">
                          {transition.projectName}
                        </span>
                      </td>
                      <td className="px-2 py-2 whitespace-nowrap">
                        <div className="flex items-center">
                          <ExternalLink className="h-3 w-3 text-blue-500 mr-1" />
                          <a
                            href={transition.taskLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:text-blue-800 font-medium text-xs"
                          >
                            <span className="hidden md:inline">{transition.taskLink.split('/').pop() || 'Jira Task'}</span>
                            <span className="md:hidden">TASK-{String(index + 1).padStart(3, '0')}</span>
                          </a>
                        </div>
                      </td>
                      <td className="px-2 py-2 whitespace-nowrap text-xs text-gray-900">
                        {transition.lastTestSubmissionDate ? 
                          new Date(transition.lastTestSubmissionDate).toLocaleDateString('en-US') : 
                          '17.07.2025'
                        }
                      </td>
                      <td className="px-2 py-2 whitespace-nowrap text-xs text-gray-900">
                        {transition.lastPackageBindingDate ? 
                          new Date(transition.lastPackageBindingDate).toLocaleDateString('en-US') : 
                          '18.07.2025'
                        }
                      </td>
                      <td className="px-2 py-2 whitespace-nowrap text-xs text-gray-900">
                        {transition.regressionDeliveryDate ? 
                          new Date(transition.regressionDeliveryDate).toLocaleDateString('en-US') : 
                          '19.07.2025'
                        }
                      </td>
                      <td className="px-2 py-2 whitespace-nowrap">
                        <span className="inline-flex items-center px-1 py-1 rounded-full text-xs font-medium text-gray-900 bg-gray-200">
                          {transition.transitionDate ? 
                            new Date(transition.transitionDate).toLocaleDateString('en-US') : 
                            '30.07.2025'
                          }
                        </span>
                      </td>
                      <td className="px-2 py-2 whitespace-nowrap">
                        <Tooltip 
                          phone={transition.managerPhone}
                          email={transition.managerEmail}
                        >
                          <span className="inline-flex items-center px-1 py-1 rounded-full text-xs font-medium text-gray-900 bg-gray-200 cursor-pointer hover:bg-indigo-100 hover:text-indigo-700 transition-all duration-200 border border-transparent hover:border-indigo-300 truncate max-w-full">
                            <span className="hidden md:inline">{transition.transitionManager || 'Suat Öztürk'}</span>
                            <span className="md:hidden">{(transition.transitionManager || 'Suat Öztürk').split(' ')[0]}</span>
                          </span>
                        </Tooltip>
                      </td>
                      <td className="px-2 py-2 whitespace-nowrap">
                        <Tooltip 
                          phone={transition.assistantPhone}
                          email={transition.assistantEmail}
                        >
                          <span className="inline-flex items-center px-1 py-1 rounded-full text-xs font-medium text-gray-900 bg-gray-200 cursor-pointer hover:bg-indigo-100 hover:text-indigo-700 transition-all duration-200 border border-transparent hover:border-indigo-300 truncate max-w-full">
                            <span className="hidden lg:inline">{transition.transitionAssistant || 'Ömer Tuğrul Tutal'}</span>
                            <span className="lg:hidden">{(transition.transitionAssistant || 'Ömer Tuğrul Tutal').split(' ')[0]}</span>
                          </span>
                        </Tooltip>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTransitions.map((transition, index) => (
              <div key={transition.id} className="bg-white/80 backdrop-blur-lg rounded-2xl p-6 shadow-lg border border-white/20 hover:shadow-xl transition-all duration-300">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center flex-1 min-w-0">
                    <div 
                      className="w-4 h-4 rounded-full mr-3 flex-shrink-0"
                      style={{ backgroundColor: transition.color }}
                    ></div>
                    <h3 className="text-lg font-semibold text-gray-900 truncate">
                      {transition.projectName}
                    </h3>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center text-sm text-gray-600">
                    <Calendar className="h-4 w-4 mr-3 flex-shrink-0" />
                    <div className="flex-1">
                      <span className="font-medium">Date Range:</span>
                      <span className="ml-2">
                        {transition.startDate} → {transition.endDate}
                      </span>
                    </div>
                  </div>
                  
                  <div className="flex items-center text-sm text-gray-600">
                    <User className="h-4 w-4 mr-3 flex-shrink-0" />
                    <div className="flex-1">
                      <span className="font-medium">Manager:</span>
                      <Tooltip 
                        phone={transition.managerPhone}
                        email={transition.managerEmail}
                      >
                        <span className="ml-2 cursor-pointer hover:text-indigo-600 hover:font-medium transition-all duration-200 underline decoration-dotted">
                          {transition.transitionManager}
                        </span>
                      </Tooltip>
                    </div>
                  </div>
                  
                  <div className="flex items-center text-sm text-gray-600">
                    <Users className="h-4 w-4 mr-3 flex-shrink-0" />
                    <div className="flex-1">
                      <span className="font-medium">Assistant:</span>
                      <Tooltip 
                        phone={transition.assistantPhone}
                        email={transition.assistantEmail}
                      >
                        <span className="ml-2 cursor-pointer hover:text-indigo-600 hover:font-medium transition-all duration-200 underline decoration-dotted">
                          {transition.transitionAssistant}
                        </span>
                      </Tooltip>
                    </div>
                  </div>
                  
                  <div className="flex items-center text-sm text-gray-600">
                    <Clock className="h-4 w-4 mr-3 flex-shrink-0" />
                    <div className="flex-1">
                      <span className="font-medium">Transition Date:</span>
                      <span className="ml-2">
                        {transition.transitionDate ? 
                          new Date(transition.transitionDate).toLocaleDateString('en-US') : 
                          'Not set'
                        }
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center text-sm text-gray-600">
                    <ExternalLink className="h-4 w-4 mr-3 flex-shrink-0" />
                    <div className="flex-1">
                      <span className="font-medium">Task:</span>
                      <span className="ml-2">
                        {transition.taskLink.split('/').pop() || 'Task Link'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center text-sm text-gray-600">
                    <Calendar className="h-4 w-4 mr-3 flex-shrink-0" />
                    <div className="flex-1">
                      <span className="font-medium">Test Submission:</span>
                      <span className="ml-2">
                        {transition.lastTestSubmissionDate ? 
                          new Date(transition.lastTestSubmissionDate).toLocaleDateString('en-US') : 
                          'Not set'
                        }
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center text-sm text-gray-600">
                    <Calendar className="h-4 w-4 mr-3 flex-shrink-0" />
                    <div className="flex-1">
                      <span className="font-medium">Package Binding:</span>
                      <span className="ml-2">
                        {transition.lastPackageBindingDate ? 
                          new Date(transition.lastPackageBindingDate).toLocaleDateString('en-US') : 
                          'Not set'
                        }
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center text-sm text-gray-600">
                    <Calendar className="h-4 w-4 mr-3 flex-shrink-0" />
                    <div className="flex-1">
                      <span className="font-medium">Regression Delivery:</span>
                      <span className="ml-2">
                        {transition.regressionDeliveryDate ? 
                          new Date(transition.regressionDeliveryDate).toLocaleDateString('en-US') : 
                          'Not set'
                        }
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <a
                    href={transition.taskLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-indigo-600 hover:text-indigo-800 text-sm font-medium transition-colors duration-200 flex items-center"
                  >
                    View Task Link →
                  </a>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* No Results Modal */}
        {showNoResults && (
          <div className="fixed inset-0 bg-gray-500 bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
              <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">No Results Found</h3>
                <button
                  onClick={() => setShowNoResults(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
              <div className="p-6 text-center">
                <Search className="mx-auto h-12 w-12 text-gray-400" />
                <h3 className="mt-2 text-lg font-medium text-gray-900">
                  No transitions found for "{searchTerm}"
                </h3>
                <p className="mt-1 text-sm text-gray-500">
                  Try searching with different keywords or check your spelling.
                </p>
                <div className="mt-6 flex justify-center">
                  <button
                    onClick={() => {
                      setSearchTerm('');
                      setShowNoResults(false);
                    }}
                    className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:from-indigo-700 hover:to-purple-700 focus:outline-none focus:ring-4 focus:ring-indigo-500/30 transition-all duration-300 transform hover:scale-105 shadow-lg"
                  >
                    Clear Search
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default HomePage; 