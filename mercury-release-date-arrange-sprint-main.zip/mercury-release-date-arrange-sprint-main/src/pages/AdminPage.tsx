import React, { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, X, Save, Calendar, User, Users, Clock, ExternalLink } from 'lucide-react';
import { Transition, TransitionFormData } from '../types';
import { getTransitions, addTransition, updateTransition, deleteTransition, PROJECT_COLORS } from '../utils/mockData';
import toast from 'react-hot-toast';
import Tooltip from '../components/Tooltip';

const AdminPage: React.FC = () => {
  const [transitions, setTransitions] = useState<Transition[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [editingTransition, setEditingTransition] = useState<Transition | null>(null);
  const [deletingTransition, setDeletingTransition] = useState<Transition | null>(null);
  const [formData, setFormData] = useState<TransitionFormData>({
    projectName: '',
    color: PROJECT_COLORS[0].value,
    taskLink: '',
    transitionTime: '',
    lastTestSubmissionDate: '',
    lastPackageBindingDate: '',
    regressionDeliveryDate: '',
    transitionDate: '',
    transitionManager: '',
    transitionAssistant: '',
    managerEmail: '',
    managerPhone: '',
    assistantEmail: '',
    assistantPhone: ''
  });

  useEffect(() => {
    const loadTransitions = async () => {
      const transitions = await getTransitions();
      setTransitions(transitions);
    };
    loadTransitions();
  }, []);

  const openModal = (transition?: Transition) => {
    if (transition) {
      setEditingTransition(transition);
      setFormData({
        projectName: transition.projectName,
        color: transition.color,
        taskLink: transition.taskLink,
        transitionTime: transition.transitionTime,
        lastTestSubmissionDate: transition.lastTestSubmissionDate,
        lastPackageBindingDate: transition.lastPackageBindingDate,
        regressionDeliveryDate: transition.regressionDeliveryDate,
        transitionDate: transition.transitionDate,
        transitionManager: transition.transitionManager,
        transitionAssistant: transition.transitionAssistant,
        managerEmail: transition.managerEmail || '',
        managerPhone: transition.managerPhone || '',
        assistantEmail: transition.assistantEmail || '',
        assistantPhone: transition.assistantPhone || ''
      });
    } else {
      setEditingTransition(null);
      setFormData({
        projectName: '',
        color: PROJECT_COLORS[0].value,
        taskLink: '',
        transitionTime: '',
        lastTestSubmissionDate: '',
        lastPackageBindingDate: '',
        regressionDeliveryDate: '',
        transitionDate: '',
        transitionManager: '',
        transitionAssistant: '',
        managerEmail: '',
        managerPhone: '',
        assistantEmail: '',
        assistantPhone: ''
      });
    }
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingTransition(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingTransition) {
        const updated = await updateTransition(editingTransition.id, formData);
        if (updated) {
          const transitions = await getTransitions();
          setTransitions(transitions);
          toast.success('Transition updated successfully!');
          closeModal();
        }
      } else {
        await addTransition(formData);
        const transitions = await getTransitions();
        setTransitions(transitions);
        toast.success('Transition added successfully!');
        closeModal();
      }
    } catch (error) {
      toast.error('An error occurred. Please try again.');
    }
  };

  const handleDelete = (transition: Transition) => {
    setDeletingTransition(transition);
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = async () => {
    if (deletingTransition) {
      try {
        const success = await deleteTransition(deletingTransition.id);
        if (success) {
          const transitions = await getTransitions();
          setTransitions(transitions);
          toast.success('Transition deleted successfully!');
        }
        setIsDeleteModalOpen(false);
        setDeletingTransition(null);
      } catch (error) {
        toast.error('An error occurred while deleting.');
      }
    }
  };

  const cancelDelete = () => {
    setIsDeleteModalOpen(false);
    setDeletingTransition(null);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const stats = {
    total: transitions.length
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50">
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-lg border-b border-white/20 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                Admin Panel
              </h1>
              <p className="text-gray-600 mt-1">Transition management and tracking</p>
            </div>
            <button
              onClick={() => openModal()}
              className="flex items-center px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:from-indigo-700 hover:to-purple-700 focus:outline-none focus:ring-4 focus:ring-indigo-500/30 transition-all duration-300 transform hover:scale-105 shadow-lg"
            >
              <Plus className="h-5 w-5 mr-2" />
              Add New Transition
            </button>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-1 gap-6 mb-8">
          <div className="bg-white/80 backdrop-blur-lg rounded-2xl p-6 shadow-lg border border-white/20">
            <div className="flex items-center">
              <div className="p-3 bg-gradient-to-r from-blue-500 to-blue-600 rounded-xl">
                <Calendar className="h-6 w-6 text-white" />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Total Transitions</p>
                <p className="text-2xl font-bold text-gray-900">{stats.total}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Transitions Table */}
        <div className="bg-white/80 backdrop-blur-lg rounded-2xl shadow-lg border border-white/20">
          <div className="px-6 py-4 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-semibold text-gray-900">Transition List</h2>
              <div className="text-sm text-gray-600">
                Total: {transitions.length} transitions
              </div>
            </div>
          </div>
          <div className="overflow-x-auto overflow-y-visible">
            <table className="w-full divide-y divide-gray-200 table-fixed">
              <thead className="bg-gradient-to-r from-purple-500 to-pink-500">
                <tr>
                  <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-20">
                    <div className="flex items-center">
                      <Clock className="h-3 w-3 mr-1" />
                      <span className="hidden sm:inline">TIME</span>
                      <span className="sm:hidden">T</span>
                    </div>
                  </th>
                  <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-24">
                    <div className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      <span className="hidden lg:inline">PROJECT</span>
                      <span className="lg:hidden">P</span>
                    </div>
                  </th>
                  <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-20">
                    <div className="flex items-center">
                      <ExternalLink className="h-3 w-3 mr-1" />
                      <span className="hidden md:inline">TASK</span>
                      <span className="md:hidden">T</span>
                    </div>
                  </th>
                  <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-20">
                    <div className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      <span className="hidden xl:inline">TEST</span>
                      <span className="xl:hidden">T</span>
                    </div>
                  </th>
                  <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-20">
                    <div className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      <span className="hidden xl:inline">PACKAGE</span>
                      <span className="xl:hidden">P</span>
                    </div>
                  </th>
                  <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-20">
                    <div className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      <span className="hidden xl:inline">REGRESSION</span>
                      <span className="xl:hidden">R</span>
                    </div>
                  </th>
                  <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-20">
                    <div className="flex items-center">
                      <Calendar className="h-3 w-3 mr-1" />
                      <span className="hidden lg:inline">DATE</span>
                      <span className="lg:hidden">D</span>
                    </div>
                  </th>
                  <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-24">
                    <div className="flex items-center">
                      <User className="h-3 w-3 mr-1" />
                      <span className="hidden md:inline">MANAGER</span>
                      <span className="md:hidden">M</span>
                    </div>
                  </th>
                  <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-24">
                    <div className="flex items-center">
                      <Users className="h-3 w-3 mr-1" />
                      <span className="hidden lg:inline">ASSISTANT</span>
                      <span className="lg:hidden">A</span>
                    </div>
                  </th>
                  <th className="px-2 py-3 text-left text-xs font-bold text-white uppercase tracking-wider w-20">
                    <div className="flex items-center">
                      <Edit className="h-3 w-3 mr-1" />
                      <span className="hidden md:inline">ACTIONS</span>
                      <span className="md:hidden">A</span>
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white/50 divide-y divide-gray-200">
                {transitions.map((transition, index) => {
                  // Transition time creation (for mock data)
                  const getTransitionTime = (index: number) => {
                    const times = [
                      '05:00 - 07:00',
                      '08:00 - 10:00', 
                      '12:00 - 14:00',
                      '15:00 - 17:00',
                      '18:00 - 20:00'
                    ];
                    return times[index % times.length];
                  };

                  // Transition time color
                  const getTimeColor = (index: number) => {
                    const colors = ['bg-purple-500', 'bg-green-500', 'bg-pink-500', 'bg-purple-500', 'bg-pink-500'];
                    return colors[index % colors.length];
                  };

                  return (
                    <tr key={transition.id} className="hover:bg-gray-50/50 transition-colors duration-200">
                      <td className="px-3 py-3 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium text-white ${getTimeColor(index)}`}>
                          <span className="hidden sm:inline">{transition.transitionTime || getTransitionTime(index)}</span>
                          <span className="sm:hidden">{(transition.transitionTime || getTransitionTime(index)).split(' ')[0]}</span>
                        </span>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium text-white ${getTimeColor(index)}`}>
                          {transition.projectName}
                        </span>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        <div className="flex items-center">
                          <ExternalLink className="h-3 w-3 text-blue-500 mr-1" />
                          <a
                            href={transition.taskLink}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:text-blue-800 font-medium text-xs"
                          >
                            <span className="hidden md:inline">{transition.taskLink.split('/').pop() || 'Jira Task'}</span>
                            <span className="md:hidden">TASK-{String(index + 1).padStart(3, '0')}</span>
                          </a>
                        </div>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-xs text-gray-900">
                        {transition.lastTestSubmissionDate ? 
                          new Date(transition.lastTestSubmissionDate).toLocaleDateString('en-US') : 
                          '17.07.2025'
                        }
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-xs text-gray-900">
                        {transition.lastPackageBindingDate ? 
                          new Date(transition.lastPackageBindingDate).toLocaleDateString('en-US') : 
                          '18.07.2025'
                        }
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-xs text-gray-900">
                        {transition.regressionDeliveryDate ? 
                          new Date(transition.regressionDeliveryDate).toLocaleDateString('en-US') : 
                          '19.07.2025'
                        }
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium text-gray-900 bg-gray-200">
                          {transition.transitionDate ? 
                            new Date(transition.transitionDate).toLocaleDateString('en-US') : 
                            '30.07.2025'
                          }
                        </span>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        <Tooltip 
                          phone={transition.managerPhone}
                          email={transition.managerEmail}
                        >
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium text-gray-900 bg-gray-200 cursor-pointer hover:bg-indigo-100 hover:text-indigo-700 transition-all duration-200 border border-transparent hover:border-indigo-300">
                            <span className="hidden md:inline">{transition.transitionManager || 'Suat Öztürk'}</span>
                            <span className="md:hidden">{(transition.transitionManager || 'Suat Öztürk').split(' ')[0]}</span>
                          </span>
                        </Tooltip>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap">
                        <Tooltip 
                          phone={transition.assistantPhone}
                          email={transition.assistantEmail}
                        >
                          <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium text-gray-900 bg-gray-200 cursor-pointer hover:bg-indigo-100 hover:text-indigo-700 transition-all duration-200 border border-transparent hover:border-indigo-300">
                            <span className="hidden lg:inline">{transition.transitionAssistant || 'Ömer Tuğrul Tutal'}</span>
                            <span className="lg:hidden">{(transition.transitionAssistant || 'Ömer Tuğrul Tutal').split(' ')[0]}</span>
                          </span>
                        </Tooltip>
                      </td>
                      <td className="px-3 py-3 whitespace-nowrap text-xs font-medium">
                        <div className="flex items-center space-x-1">
                          <button
                            onClick={() => openModal(transition)}
                            className="text-indigo-600 hover:text-indigo-900 transition-colors duration-200 p-1"
                          >
                            <Edit className="h-3 w-3" />
                          </button>
                          <button
                            onClick={() => handleDelete(transition)}
                            className="text-red-600 hover:text-red-900 transition-colors duration-200 p-1"
                          >
                            <Trash2 className="h-3 w-3" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">
                {editingTransition ? 'Edit Transition' : 'Add New Transition'}
              </h3>
              <button
                onClick={closeModal}
                className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Project Name
                  </label>
                  <input
                    type="text"
                    name="projectName"
                    value={formData.projectName}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all duration-300"
                    placeholder="Enter project name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Project Color
                  </label>
                  <div className="grid grid-cols-4 gap-2">
                    {PROJECT_COLORS.slice(0, 8).map((color) => (
                      <button
                        key={color.value}
                        type="button"
                        onClick={() => setFormData({ ...formData, color: color.value })}
                        className={`w-full h-10 rounded-lg border-2 transition-all duration-200 ${
                          formData.color === color.value
                            ? 'border-indigo-600 scale-110 shadow-lg'
                            : 'border-gray-300 hover:border-gray-400'
                        }`}
                        style={{ backgroundColor: color.value }}
                        title={color.name}
                      />
                    ))}
                  </div>
                  <p className="text-xs text-gray-500 mt-1">
                    Selected: {PROJECT_COLORS.find(c => c.value === formData.color)?.name}
                  </p>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Task Link
                </label>
                <input
                  type="url"
                  name="taskLink"
                  value={formData.taskLink}
                  onChange={handleInputChange}
                  className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all duration-300"
                  placeholder="https://jira.company.com/browse/PROJECT-123"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Transition Time
                  </label>
                  <div className="relative">
                    <select
                      name="transitionTime"
                      value={formData.transitionTime}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all duration-300"
                    >
                      <option value="">Select a time slot</option>
                      <option value="05:00 - 07:00">05:00 - 07:00</option>
                      <option value="08:00 - 10:00">08:00 - 10:00</option>
                      <option value="12:00 - 14:00">12:00 - 14:00</option>
                      <option value="15:00 - 17:00">15:00 - 17:00</option>
                      <option value="18:00 - 20:00">18:00 - 20:00</option>
                    </select>
                    <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Last Test Submission Date
                  </label>
                  <div className="relative">
                    <input
                      type="date"
                      name="lastTestSubmissionDate"
                      value={formData.lastTestSubmissionDate}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all duration-300"
                    />
                    <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Last Package Binding Date
                  </label>
                  <div className="relative">
                    <input
                      type="date"
                      name="lastPackageBindingDate"
                      value={formData.lastPackageBindingDate}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all duration-300"
                    />
                    <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Regression Delivery Date
                  </label>
                  <div className="relative">
                    <input
                      type="date"
                      name="regressionDeliveryDate"
                      value={formData.regressionDeliveryDate}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all duration-300"
                    />
                    <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Transition Date
                  </label>
                  <div className="relative">
                    <input
                      type="date"
                      name="transitionDate"
                      value={formData.transitionDate}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 pr-10 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all duration-300"
                    />
                    <Calendar className="absolute right-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Transition Manager
                  </label>
                  <input
                    type="text"
                    name="transitionManager"
                    value={formData.transitionManager}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all duration-300"
                    placeholder="Manager name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Manager Email
                  </label>
                  <input
                    type="email"
                    name="managerEmail"
                    value={formData.managerEmail}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all duration-300"
                    placeholder="manager@company.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Manager Phone
                  </label>
                  <input
                    type="tel"
                    name="managerPhone"
                    value={formData.managerPhone}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all duration-300"
                    placeholder="+90 532 123 4567"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Transition Assistant
                  </label>
                  <input
                    type="text"
                    name="transitionAssistant"
                    value={formData.transitionAssistant}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all duration-300"
                    placeholder="Assistant name"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Assistant Email
                  </label>
                  <input
                    type="email"
                    name="assistantEmail"
                    value={formData.assistantEmail}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all duration-300"
                    placeholder="assistant@company.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Assistant Phone
                  </label>
                  <input
                    type="tel"
                    name="assistantPhone"
                    value={formData.assistantPhone}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all duration-300"
                    placeholder="+90 533 987 6543"
                  />
                </div>
              </div>

              <div className="flex justify-end space-x-3 pt-6 border-t border-gray-200">
                <button
                  type="button"
                  onClick={closeModal}
                  className="px-6 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-all duration-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 text-white rounded-xl hover:from-indigo-700 hover:to-purple-700 focus:outline-none focus:ring-4 focus:ring-indigo-500/30 transition-all duration-300 transform hover:scale-105 shadow-lg"
                >
                  <Save className="h-4 w-4 inline mr-2" />
                  {editingTransition ? 'Update' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {isDeleteModalOpen && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">Confirm Deletion</h3>
              <button
                onClick={cancelDelete}
                className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
              >
                <X className="h-6 w-6" />
              </button>
            </div>
            <div className="p-6 text-center">
              <Trash2 className="mx-auto h-12 w-12 text-red-500" />
              <h3 className="mt-2 text-lg font-medium text-gray-900">
                Are you sure you want to delete this transition?
              </h3>
              <p className="mt-1 text-sm text-gray-500">
                This action cannot be undone.
              </p>
              <div className="mt-6 flex justify-center space-x-3">
                <button
                  onClick={cancelDelete}
                  className="px-6 py-3 border border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-all duration-300"
                >
                  Cancel
                </button>
                <button
                  onClick={confirmDelete}
                  className="px-6 py-3 bg-red-600 text-white rounded-xl hover:bg-red-700 focus:outline-none focus:ring-4 focus:ring-red-500/30 transition-all duration-300 transform hover:scale-105 shadow-lg"
                >
                  Delete
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminPage; 