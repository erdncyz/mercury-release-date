#!/usr/bin/env node

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { 
  connectRedis, 
  getFromRedis, 
  setToRedis, 
  REDIS_KEYS 
} = require('./src/utils/redis');

// Database file path
const DB_PATH = path.join(__dirname, 'data.json');

// Default credentials
const DEFAULT_CREDENTIALS = {
  username: 'admin',
  password: 'admin123'
};

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

function readline() {
  const readline = require('readline');
  return readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
}

async function readDatabase() {
  try {
    // Önce Redis'ten okumayı dene
    const redisData = await getFromRedis(REDIS_KEYS.DATABASE_INFO);
    if (redisData) {
      log('📖 Redis\'ten veri okundu', 'green');
      return redisData;
    }
    
    // Redis'te yoksa dosyadan oku
    if (fs.existsSync(DB_PATH)) {
      const data = fs.readFileSync(DB_PATH, 'utf8');
      const parsedData = JSON.parse(data);
      
      // Redis'e yaz
      await setToRedis(REDIS_KEYS.DATABASE_INFO, parsedData, 86400);
      log('📁 Dosyadan okundu ve Redis\'e yazıldı', 'blue');
      return parsedData;
    }
  } catch (error) {
    log('Error reading database file', 'red');
  }
  return null;
}

async function writeDatabase(data) {
  try {
    // Hem Redis'e hem dosyaya yaz
    const redisSuccess = await setToRedis(REDIS_KEYS.DATABASE_INFO, data, 86400);
    const fileSuccess = fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
    
    if (redisSuccess) {
      log('✅ Redis\'e yazıldı', 'green');
    }
    if (fileSuccess !== undefined) {
      log('✅ Dosyaya yazıldı', 'green');
    }
    
    return redisSuccess || fileSuccess !== undefined;
  } catch (error) {
    log('Error writing database file', 'red');
    return false;
  }
}

async function initializeDatabase() {
  const db = await readDatabase();
  if (db) {
    return db;
  }
  
  // Create new database with default data
  const newDb = {
    transitions: [],
    adminCredentials: DEFAULT_CREDENTIALS,
    settings: {
      version: '1.0.0',
      lastUpdated: new Date().toISOString()
    }
  };
  
  await writeDatabase(newDb);
  return newDb;
}

async function showCurrentCredentials() {
  const db = await readDatabase();
  if (db && db.adminCredentials) {
    log('\n🔐 Current Admin Credentials:', 'cyan');
    log('============================', 'cyan');
    log(`   Username: ${db.adminCredentials.username}`, 'green');
    log(`   Password: ${db.adminCredentials.password}`, 'green');
    log(`   Database: ${DB_PATH}`, 'blue');
  } else {
    log('\n❌ No database found.', 'red');
    log('Run the setup to create admin credentials.', 'yellow');
  }
}

function createDefaultCredentials() {
  const db = initializeDatabase();
  db.adminCredentials = DEFAULT_CREDENTIALS;
  db.settings.lastUpdated = new Date().toISOString();
  
  const success = writeDatabase(db);
  if (success) {
    log('\n✅ Default admin credentials created successfully!', 'green');
    log('\n🔐 Default Admin Credentials:', 'cyan');
    log('============================', 'cyan');
    log(`   Username: ${DEFAULT_CREDENTIALS.username}`, 'green');
    log(`   Password: ${DEFAULT_CREDENTIALS.password}`, 'green');
    log(`   Database: ${DB_PATH}`, 'blue');
    log('\n💡 You can now login to the admin panel with these credentials.', 'blue');
  } else {
    log('\n❌ Failed to create default credentials.', 'red');
  }
}

async function createCustomCredentials() {
  const rl = readline();
  
  log('\n🔄 Update Admin Credentials', 'cyan');
  log('=========================', 'cyan');
  
  const db = await initializeDatabase();
  const currentCredentials = db.adminCredentials || DEFAULT_CREDENTIALS;
  
  rl.question(`Enter new username (or press Enter to keep "${currentCredentials.username}"): `, async (username) => {
    rl.question(`Enter new password (or press Enter to keep "${currentCredentials.password}"): `, async (password) => {
      rl.close();
      
      const newCredentials = {
        username: username.trim() || currentCredentials.username,
        password: password.trim() || currentCredentials.password
      };
      
      db.adminCredentials = newCredentials;
      db.settings.lastUpdated = new Date().toISOString();
      
      const success = await writeDatabase(db);
      if (success) {
        log('\n✅ Admin credentials updated successfully!', 'green');
        log('\n🔐 New Admin Credentials:', 'cyan');
        log('=======================', 'cyan');
        log(`   Username: ${newCredentials.username}`, 'green');
        log(`   Username: ${newCredentials.username}`, 'green');
        log(`   Password: ${newCredentials.password}`, 'green');
        log(`   Database: ${DB_PATH}`, 'blue');
        log('\n💡 You can now login to the admin panel with these credentials.', 'blue');
      } else {
        log('\n❌ Failed to update credentials.', 'red');
      }
    });
  });
}

async function showDatabaseInfo() {
  const db = await readDatabase();
  if (db) {
    log('\n📊 Database Information:', 'cyan');
    log('=======================', 'cyan');
    log(`   Database File: ${DB_PATH}`, 'blue');
    log(`   Version: ${db.settings.version}`, 'green');
    log(`   Last Updated: ${db.settings.lastUpdated}`, 'green');
    log(`   Transitions Count: ${db.transitions.length}`, 'green');
    log(`   Admin Username: ${db.adminCredentials.username}`, 'green');
  } else {
    log('\n❌ No database found.', 'red');
  }
}

function showHelp() {
  log('\n🚀 Mercury Release Date - Admin Setup', 'bright');
  log('=====================================', 'bright');
  log('\nThis script helps you set up admin credentials for the Mercury Release Date application.');
  log('\nUsage:', 'yellow');
  log('  node setup-admin.js [option]', 'cyan');
  log('\nOptions:', 'yellow');
  log('  --default    Create default admin credentials', 'cyan');
  log('  --show       Show current admin credentials', 'cyan');
  log('  --info       Show database information', 'cyan');
  log('  --help       Show this help message', 'cyan');
  log('  (no option)  Interactive setup', 'cyan');
  log('\nExamples:', 'yellow');
  log('  node setup-admin.js --default', 'cyan');
  log('  node setup-admin.js --show', 'cyan');
  log('  node setup-admin.js --info', 'cyan');
  log('  node setup-admin.js', 'cyan');
}

function interactiveSetup() {
  const rl = readline();
  
  log('\n🚀 Mercury Release Date - Admin Setup', 'bright');
  log('=====================================', 'bright');
  log('\nChoose an option:');
  log('1. Create default admin credentials');
  log('2. Create custom admin credentials');
  log('3. Show current credentials');
  log('4. Show database information');
  log('5. Exit');
  
  rl.question('\nEnter your choice (1-5): ', (choice) => {
    rl.close();
    
    switch (choice.trim()) {
      case '1':
        createDefaultCredentials();
        break;
      case '2':
        createCustomCredentials();
        break;
      case '3':
        showCurrentCredentials();
        break;
      case '4':
        showDatabaseInfo();
        break;
      case '5':
        log('\n👋 Goodbye!', 'green');
        break;
      default:
        log('\n❌ Invalid choice. Please run the script again.', 'red');
    }
  });
}

// Main execution
function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    interactiveSetup();
  } else {
    const option = args[0];
    
    switch (option) {
      case '--default':
        createDefaultCredentials();
        break;
      case '--show':
        showCurrentCredentials();
        break;
      case '--info':
        showDatabaseInfo();
        break;
      case '--help':
        showHelp();
        break;
      default:
        log(`❌ Unknown option: ${option}`, 'red');
        showHelp();
    }
  }
}

// Run the script
if (require.main === module) {
  main();
}

module.exports = {
  readDatabase,
  writeDatabase,
  initializeDatabase,
  createDefaultCredentials,
  createCustomCredentials,
  showCurrentCredentials,
  showDatabaseInfo
}; 