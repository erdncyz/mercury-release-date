require('dotenv').config();
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const { 
  connectRedis, 
  getFromRedis, 
  setToRedis, 
  deleteFromRedis, 
  clearRedisCache,
  getRedisCacheStatus,
  disconnectRedis, 
  REDIS_KEYS 
} = require('./src/utils/redis');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_FILE = path.join(__dirname, 'data.json');

// Middleware
app.use(cors({
  origin: true, // Tüm origin'lere izin ver
  credentials: true
}));
app.use(express.json());

// Serve static files from the React app
app.use(express.static(path.join(__dirname, 'build')));

// Database interface
const DEFAULT_DATA = {
  transitions: [],
  adminCredentials: {
    username: 'admin',
    password: 'admin123'
  },
  settings: {
    version: '1.0.0',
    lastUpdated: new Date().toISOString()
  }
};

// Database operations (Redis + File fallback)
const readDatabase = async () => {
  try {
    // Önce Redis'ten okumayı dene
    const redisData = await getFromRedis(REDIS_KEYS.DATABASE_INFO);
    if (redisData) {
      console.log('📖 Redis\'ten veri okundu');
      return redisData;
    }
    
    // Redis'te yoksa dosyadan oku
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf8');
      const parsedData = JSON.parse(data);
      
      // Redis'e yaz
      await setToRedis(REDIS_KEYS.DATABASE_INFO, parsedData, 86400); // 24 saat
      console.log('📁 Dosyadan okundu ve Redis\'e yazıldı');
      return parsedData;
    }
  } catch (error) {
    console.error('Error reading database:', error);
  }
  return null;
};

const writeDatabase = async (data) => {
  try {
    // Hem Redis'e hem dosyaya yaz
    const redisSuccess = await setToRedis(REDIS_KEYS.DATABASE_INFO, data, 86400);
    const fileSuccess = fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
    
    if (redisSuccess) {
      console.log('✅ Redis\'e yazıldı');
    }
    if (fileSuccess !== undefined) {
      console.log('✅ Dosyaya yazıldı');
    }
    
    return redisSuccess || fileSuccess !== undefined;
  } catch (error) {
    console.error('Error writing database:', error);
    return false;
  }
};

const initializeDatabase = async () => {
  const db = await readDatabase();
  if (db) {
    return db;
  }
  
  // Create new database with default data
  const newDb = { ...DEFAULT_DATA };
  await writeDatabase(newDb);
  return newDb;
};

// API Routes

// Get all transitions
app.get('/api/transitions', async (req, res) => {
  try {
    const db = await initializeDatabase();
    res.json(db.transitions);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get transitions' });
  }
});

// Add new transition
app.post('/api/transitions', async (req, res) => {
  try {
    const db = await initializeDatabase();
    const newTransition = {
      id: Date.now().toString(),
      ...req.body
    };
    
    db.transitions.push(newTransition);
    db.settings.lastUpdated = new Date().toISOString();
    
    if (await writeDatabase(db)) {
      res.json(newTransition);
    } else {
      res.status(500).json({ error: 'Failed to save transition' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Failed to add transition' });
  }
});

// Update transition
app.put('/api/transitions/:id', async (req, res) => {
  try {
    const db = await initializeDatabase();
    const { id } = req.params;
    const index = db.transitions.findIndex(t => t.id === id);
    
    if (index === -1) {
      return res.status(404).json({ error: 'Transition not found' });
    }
    
    db.transitions[index] = { ...db.transitions[index], ...req.body };
    db.settings.lastUpdated = new Date().toISOString();
    
    if (await writeDatabase(db)) {
      res.json(db.transitions[index]);
    } else {
      res.status(500).json({ error: 'Failed to update transition' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Failed to update transition' });
  }
});

// Delete transition
app.delete('/api/transitions/:id', async (req, res) => {
  try {
    const db = await initializeDatabase();
    const { id } = req.params;
    const filteredTransitions = db.transitions.filter(t => t.id !== id);
    
    if (filteredTransitions.length === db.transitions.length) {
      return res.status(404).json({ error: 'Transition not found' });
    }
    
    db.transitions = filteredTransitions;
    db.settings.lastUpdated = new Date().toISOString();
    
    if (await writeDatabase(db)) {
      res.json({ success: true });
    } else {
      res.status(500).json({ error: 'Failed to delete transition' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete transition' });
  }
});

// Get admin credentials
app.get('/api/admin/credentials', async (req, res) => {
  try {
    const db = await initializeDatabase();
    res.json(db.adminCredentials);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get admin credentials' });
  }
});

// Update admin credentials
app.put('/api/admin/credentials', async (req, res) => {
  try {
    const db = await initializeDatabase();
    const { username, password } = req.body;
    
    db.adminCredentials = { username, password };
    db.settings.lastUpdated = new Date().toISOString();
    
    if (await writeDatabase(db)) {
      res.json(db.adminCredentials);
    } else {
      res.status(500).json({ error: 'Failed to update admin credentials' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Failed to update admin credentials' });
  }
});

// Get database info
app.get('/api/database/info', async (req, res) => {
  try {
    const db = await initializeDatabase();
    res.json({
      filePath: DB_FILE,
      version: db.settings.version,
      lastUpdated: db.settings.lastUpdated,
      transitionsCount: db.transitions.length,
      adminUsername: db.adminCredentials.username
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to get database info' });
  }
});

// Backup database
app.get('/api/database/backup', async (req, res) => {
  try {
    const db = await initializeDatabase();
    res.json(db);
  } catch (error) {
    res.status(500).json({ error: 'Failed to backup database' });
  }
});

// Restore database
app.post('/api/database/restore', async (req, res) => {
  try {
    if (await writeDatabase(req.body)) {
      res.json({ success: true });
    } else {
      res.status(500).json({ error: 'Failed to restore database' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Failed to restore database' });
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    databaseFile: DB_FILE,
    databaseExists: fs.existsSync(DB_FILE)
  });
});

// Redis cache durumu
app.get('/api/redis/status', async (req, res) => {
  try {
    const status = await getRedisCacheStatus();
    res.json(status);
  } catch (error) {
    res.status(500).json({ error: 'Failed to get Redis status' });
  }
});

// Redis cache temizle
app.post('/api/redis/clear', async (req, res) => {
  try {
    const success = await clearRedisCache();
    if (success) {
      res.json({ success: true, message: 'Redis cache cleared successfully' });
    } else {
      res.status(500).json({ error: 'Failed to clear Redis cache' });
    }
  } catch (error) {
    res.status(500).json({ error: 'Failed to clear Redis cache' });
  }
});

// Serve React app for all non-API routes
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'build', 'index.html'));
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(__dirname, 'build', 'index.html'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, 'build', 'index.html'));
});

// Serve static files
app.use(express.static(path.join(__dirname, 'build')));

// Catch all other routes (but not API routes)
app.use((req, res) => {
  // Don't serve index.html for API routes
  if (req.path && req.path.startsWith('/api/')) {
    return res.status(404).json({ error: 'API endpoint not found' });
  }
  res.sendFile(path.join(__dirname, 'build', 'index.html'));
});

// Start server
app.listen(PORT, '0.0.0.0', async () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`📁 Database file: ${DB_FILE}`);
  console.log(`🔗 API available at: http://localhost:${PORT}/api`);
  console.log(`🌐 API available at: http://0.0.0.0:${PORT}/api (all interfaces)`);
  console.log(`💚 Health check: http://localhost:${PORT}/api/health`);
  console.log(`🔍 Server listening on all interfaces (0.0.0.0:${PORT})`);
  
  // Redis bağlantısını test et
  try {
    await connectRedis();
    console.log('🔴 Redis bağlantısı başarılı');
  } catch (error) {
    console.log('⚠️ Redis bağlantısı başarısız, dosya sistemi kullanılacak');
  }
}); 