#!/usr/bin/env node

require('dotenv').config();
const { 
  clearRedisCache, 
  getRedisCacheStatus,
  connectRedis 
} = require('./src/utils/redis');

// Colors for console output
const colors = {
  reset: '\x1b[0m',
  bright: '\x1b[1m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  magenta: '\x1b[35m',
  cyan: '\x1b[36m'
};

function log(message, color = 'reset') {
  console.log(`${colors[color]}${message}${colors.reset}`);
}

async function showCacheStatus() {
  try {
    log('\n🔍 Redis Cache Durumu', 'bright');
    log('==================', 'bright');
    
    const status = await getRedisCacheStatus();
    if (status) {
      log(`\n📊 Toplam Key Sayısı: ${status.totalKeys}`, 'blue');
      
      if (status.keys.length > 0) {
        log('\n🔑 Mevcut Key\'ler:', 'cyan');
        status.keys.forEach(key => {
          log(`   - ${key}`, 'green');
        });
      }
      
      if (status.databaseInfo) {
        log('\n📁 Database Bilgileri:', 'cyan');
        log(`   - Transitions: ${status.databaseInfo.transitions.length}`, 'green');
        log(`   - Admin: ${status.databaseInfo.adminCredentials.username}`, 'green');
        log(`   - Version: ${status.databaseInfo.settings.version}`, 'green');
      }
    } else {
      log('\n❌ Redis durumu alınamadı.', 'red');
    }
  } catch (error) {
    log(`❌ Hata: ${error.message}`, 'red');
  }
}

async function clearCache() {
  try {
    log('\n🗑️ Redis Cache Temizleme', 'bright');
    log('======================', 'bright');
    
    const success = await clearRedisCache();
    if (success) {
      log('\n✅ Cache başarıyla temizlendi!', 'green');
    } else {
      log('\n❌ Cache temizlenirken hata oluştu.', 'red');
    }
  } catch (error) {
    log(`❌ Hata: ${error.message}`, 'red');
  }
}

async function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  
  switch (command) {
    case 'status':
      await showCacheStatus();
      break;
    case 'clear':
      await clearCache();
      break;
    default:
      log('\n🚀 Mercury Release Date - Cache Manager', 'bright');
      log('====================================', 'bright');
      log('\nKullanım:', 'yellow');
      log('  node cache-manager.js status  - Cache durumunu göster', 'cyan');
      log('  node cache-manager.js clear   - Cache\'i temizle', 'cyan');
      log('\nÖrnekler:', 'yellow');
      log('  node cache-manager.js status', 'cyan');
      log('  node cache-manager.js clear', 'cyan');
  }
}

main(); 